# 결재함 보내기 전 검토 확인 훅. .claude/settings.json 의 PreToolUse 훅이 셸 명령을 실행하기 직전에 부릅니다.
# send_report.py 를 실행하려는 명령이면, 보낼 보고서의 검토 기록(out/검토기록_<설비>_<YYYYMMDD>.md)을 찾아
# 마지막 「결과:」 줄이 「통과」인지 봅니다. 아니면 종료 코드 2로 끝나 실행을 막고 이유를 보여 줍니다.
import json
import os
import re
import sys

FOLDER = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
try:
    event = json.loads(sys.stdin.buffer.read().decode('utf-8', 'replace'))
except Exception:
    sys.exit(0)                                    # 입력을 읽지 못하면 이 훅은 관여하지 않습니다
command = str((event.get('tool_input') or {}).get('command') or '')
if 'send_report.py' not in command:
    sys.exit(0)

def block(reason):
    sys.stderr.write('검토를 통과하지 않은 보고서는 결재함에 보낼 수 없습니다. ' + reason + '\n')
    sys.exit(2)

found = re.search(r'틸트조치보고서_([^\s"\'\\/]+)_(\d{8})\.pdf', command)
if not found:
    block('보낼 보고서 이름(틸트조치보고서_<설비>_<YYYYMMDD>.pdf)을 명령에서 찾지 못했습니다.')
record = os.path.join(FOLDER, 'out', f'검토기록_{found.group(1)}_{found.group(2)}.md')
if not os.path.exists(record):
    block(f'검토 기록이 없습니다: out/검토기록_{found.group(1)}_{found.group(2)}.md · report-reviewer 로 먼저 검토받아 주세요.')
results = re.findall(r'결과\s*[:：]\s*(통과|보완)', open(record, encoding='utf-8').read())
if not results:
    block('검토 기록에 「결과: 통과」 또는 「결과: 보완」 줄이 없습니다.')
if results[-1] != '통과':
    block(f'마지막 검토 결과가 「{results[-1]}」입니다. 고친 뒤 다시 검토받아 주세요.')
sys.exit(0)
