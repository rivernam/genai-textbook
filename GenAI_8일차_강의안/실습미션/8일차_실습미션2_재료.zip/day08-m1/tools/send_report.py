# 틸트 조치 보고서 PDF 를 품질팀 결재함(outbox 폴더)에 넣습니다.
# 사용: python tools/send_report.py <보고서 PDF>
import datetime
import json
import os
import shutil
import sys

sys.stdout.reconfigure(encoding='utf-8')
if len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]):
    print(json.dumps({'error': '보낼 보고서 PDF 경로를 확인해 주세요. 사용: python tools/send_report.py <보고서 PDF>'}, ensure_ascii=False))
    sys.exit(1)
os.makedirs('outbox', exist_ok=True)
target = os.path.join('outbox', os.path.basename(sys.argv[1]))
shutil.copyfile(sys.argv[1], target)
print(json.dumps({'sent': target, 'time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}, ensure_ascii=False))
