# 7일차 실습 미션 1 의 틸트 판정 함수를 명령으로 옮긴 판입니다.
# 사용: python tools/grade_tilt.py <제품군> <틸트 측정값(도)>
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

TILT_LIMITS = {               # 제품군: (A 상한, B 상한, C 상한), 단위 도
    'PKG-A100': (0.3, 0.6, 0.8),
    'PKG-A200': (0.25, 0.5, 0.7),
    'PKG-B300': (0.3, 0.6, 0.8),
    'PKG-B310': (0.2, 0.4, 0.6),
    'PKG-C500': (0.4, 0.8, 1.0),
}


def grade_tilt(product, value):
    """제품군과 틸트 측정값(도)을 받아 관리 규격표로 등급(A, B, C, OUT)을 판정합니다"""
    if product not in TILT_LIMITS:
        return {'error': f'{product} 의 틸트 관리 규격이 없습니다'}
    a, b, c = TILT_LIMITS[product]
    grade = 'A' if value <= a else 'B' if value <= b else 'C' if value <= c else 'OUT'
    return {'product': product, 'value': value, 'grade': grade}


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(json.dumps({'error': '사용법: python tools/grade_tilt.py <제품군> <틸트 측정값(도)>'}, ensure_ascii=False))
        sys.exit(1)
    try:
        value = float(sys.argv[2])
    except ValueError:
        print(json.dumps({'error': f'{sys.argv[2]} 는 숫자가 아닙니다'}, ensure_ascii=False))
        sys.exit(1)
    print(json.dumps(grade_tilt(sys.argv[1], value), ensure_ascii=False))
