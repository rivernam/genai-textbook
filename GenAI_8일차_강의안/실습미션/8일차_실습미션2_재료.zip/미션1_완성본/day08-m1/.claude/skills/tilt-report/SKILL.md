---
name: tilt-report
description: 틸트 검사 결과 csv(data/<설비>_<검사일>.csv)로 등급별 조치 보고서 PDF 를 만들 때 씁니다. 품질팀 보고서 양식을 사용합니다. 설비와 검사일만 말하고 검사 결과를 정리해 달라고 할 때도 씁니다.
---

# 틸트 판정 조치 보고서 PDF

day08-m1 폴더에서 실행합니다. 등급, 조치, 건수는 스크립트가 정하므로 직접 계산하거나 문구를 바꾸지 않습니다.

## 순서

1. 판정 json 만들기
   `python .claude/skills/tilt-report/scripts/build_report_json.py data/<설비>_<YYYYMMDD>.csv`
   - `out/report_<설비>_<YYYYMMDD>.json` 이 만들어지고, 등급별 건수와 재측정(C)·보류(OUT) 스트립 목록이 출력됩니다.
   - 조치 문구: A, B = 합격(다음 공정), C = 재측정(다이 5개 재측정), OUT = 보류(AC-HOLD), 콜릿 점검. PKG-SOP-006_v1.0 「등급별 조치」 기준입니다.
   - error 가 나오면(규격 없는 제품군, 파일 이름 형식 등) 그 내용을 사용자에게 알리고 멈춥니다.
2. 종합 의견 쓰기 (이 단계만 직접 작성)
   - 재측정(C)이나 보류(OUT)가 있으면 `python tools/search_docs.py "<찾을 내용>" [개수]` 로 후속 조치를 찾습니다.
     예: 틸트 등급별 조치, 보류 통보, 콜릿 점검(PKG-SOP-006 이 가리키는 PKG-MAN-003, PKG-NOTI-003).
   - 검색 결과에 나온 내용만 씁니다. 문장마다 끝에 `[문서번호_판]` 을 붙입니다. 예: `[PKG-SOP-006_v1.0]`
   - json 의 `opinions` 에 문장 목록으로, `basis` 에 인용한 문서번호_판 목록으로 채워 json 을 다시 저장합니다.
   - 재측정·보류가 없으면 `opinions` 는 비워 둡니다(양식에 "특이 사항 없음"으로 나옵니다).
   - 문서에 없는 내용(합격 기준값, 점검 판정 기준 등)은 추측하지 않고, 필요하면 문서에서 확인하지 못했다고 씁니다.
3. PDF 만들기
   `python .claude/skills/tilt-report/report-form/make_pdf.py out/report_<설비>_<YYYYMMDD>.json`
   - 양식은 `report-form/report.html` 입니다. `out/틸트조치보고서_<설비>_<YYYYMMDD>.pdf` 가 만들어집니다.
   - 인쇄에 Edge 나 Chrome 이 필요합니다. 없으면 같은 폴더의 html 을 브라우저로 열어 PDF 로 인쇄하라고 안내합니다.
4. 사용자에게 PDF 경로, 등급별 건수, 재측정·보류 스트립을 알립니다.
