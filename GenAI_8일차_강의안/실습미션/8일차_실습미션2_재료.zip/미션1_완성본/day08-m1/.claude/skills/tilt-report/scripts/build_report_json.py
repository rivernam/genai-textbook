# 틸트 검사 결과 csv 를 판정해 보고서 json(종합 의견 제외)을 만듭니다.
# 사용: python .claude/skills/tilt-report/scripts/build_report_json.py data/<설비>_<YYYYMMDD>.csv   (day08-m1 폴더에서 실행합니다)
# 결과: out/report_<설비>_<YYYYMMDD>.json 을 쓰고, 경로와 건수를 JSON 한 줄로 출력합니다.
import csv
import json
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
WORK = Path.cwd()
sys.path.insert(0, str(WORK / 'tools'))
from grade_tilt import grade_tilt  # noqa: E402

# PKG-SOP-006_v1.0 「등급별 조치」 에 맞춘 조치 문구와 구분
ACTIONS = {
    'A': ('합격', '다음 공정'),
    'B': ('합격', '다음 공정'),
    'C': ('재측정', '다이 5개 재측정'),
    'OUT': ('보류', '보류(AC-HOLD), 콜릿 점검'),
}


def fail(message):
    print(json.dumps({'error': message}, ensure_ascii=False))
    sys.exit(1)


def main():
    if len(sys.argv) != 2:
        fail('사용법: python build_report_json.py data/<설비>_<YYYYMMDD>.csv')
    source = Path(sys.argv[1])
    found = re.fullmatch(r'(.+)_(\d{4})(\d{2})(\d{2})', source.stem)
    if not found or not source.exists():
        fail(f'{source} 를 찾지 못했거나 파일 이름이 <설비>_<YYYYMMDD>.csv 형식이 아닙니다')
    equipment, date = found.group(1), '-'.join(found.groups()[1:])

    rows, totals = [], {'합격': 0, '재측정': 0, '보류': 0}
    for line in csv.DictReader(open(source, encoding='utf-8-sig')):
        result = grade_tilt(line['product'], float(line['tilt_deg']))
        if 'error' in result:
            fail(f"{line['strip_id']}: {result['error']}")
        group, action = ACTIONS[result['grade']]
        totals[group] += 1
        rows.append({'strip_id': line['strip_id'], 'product': line['product'], 'tilt_deg': float(line['tilt_deg']),
                     'grade': result['grade'], 'action': action})

    report = {'equipment': equipment, 'date': date, 'rows': rows, 'totals': totals, 'opinions': [], 'basis': ['PKG-SOP-006_v1.0']}
    out = WORK / 'out'
    out.mkdir(exist_ok=True)
    path = out / f'report_{equipment}_{date.replace("-", "")}.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8')
    grades = {g: sum(r['grade'] == g for r in rows) for g in ['A', 'B', 'C', 'OUT']}
    print(json.dumps({'report_json': str(path.relative_to(WORK)), 'rows': len(rows), 'grades': grades, 'totals': totals,
                      'recheck': [r['strip_id'] for r in rows if r['grade'] == 'C'],
                      'hold': [r['strip_id'] for r in rows if r['grade'] == 'OUT']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
