# 7일차 실습 미션 2 의 문서 검색기를 명령으로 옮긴 판입니다.
# 이 PC 에서 가볍게 돌도록, 임베딩 모델 대신 두 글자 조각이 많이 겹치는 절을 가까운 절로 찾습니다.
# 사용: python tools/search_docs.py "찾을 내용" [개수]
import csv
import json
import os
import re
import sys
import unicodedata
from collections import Counter

FOLDER = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8')

manifest = {}
for row in csv.DictReader(open(os.path.join(FOLDER, 'docs7_manifest.csv'), encoding='utf-8-sig')):
    manifest[row['file']] = row

chunks = []                                            # 설비 문서를 ## 절 단위로 나눈 조각
for name in sorted(os.listdir(os.path.join(FOLDER, 'docs7'))):
    name = unicodedata.normalize('NFC', name)
    if not name.endswith('.md'):
        continue
    meta = manifest[name]
    text = open(os.path.join(FOLDER, 'docs7', name), encoding='utf-8').read()
    for section in re.split(r'\n(?=## )', text):
        section = section.strip()
        chunks.append({'doc_id': meta['doc_id'], 'version': meta['version'], 'title': meta['title'],
                       'section': section.splitlines()[0].lstrip('# ').strip(), 'text': section[:1200]})


def two_letter_pieces(text):
    """공백을 뺀 글을 두 글자씩 잘라 개수를 셉니다"""
    text = re.sub(r'\s+', '', text)
    return Counter(text[i:i + 2] for i in range(len(text) - 1))


def search_docs(query, k=4):
    """설비 문서에서 문의와 가까운 절 k개를 찾습니다. 결과마다 문서번호(doc_id)와 판(version)이 붙습니다"""
    query_pieces = two_letter_pieces(query)
    scored = []
    for chunk in chunks:
        chunk_pieces = two_letter_pieces(chunk['title'] + chunk['section'] + chunk['text'])
        overlap = sum(min(count, chunk_pieces[piece]) for piece, count in query_pieces.items())
        scored.append((overlap / (1 + len(chunk_pieces) ** 0.5), chunk))
    scored.sort(key=lambda pair: -pair[0])
    hits = []
    for score, chunk in scored[:k]:
        hits.append({'doc_id': chunk['doc_id'], 'version': chunk['version'], 'title': chunk['title'],
                     'section': chunk['section'], 'text': chunk['text'][:600]})
    return {'hits': hits}


if __name__ == '__main__':
    count = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    print(json.dumps(search_docs(sys.argv[1], count), ensure_ascii=False))
