# 실습 미션 1 검사. 사용: python tools/check_m1.py
# 단계마다 만든 것이 있는지, 보고서의 등급 · 조치 · 건수가 맞는지 확인하고, 세션별 도구 실행 기록표를 보여 줍니다.
import csv
import glob
import json
import os
import re
import subprocess
import sys
from html.parser import HTMLParser

FOLDER = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8')
os.chdir(FOLDER)

TILT_LIMITS = {'PKG-A100': (0.3, 0.6, 0.8), 'PKG-A200': (0.25, 0.5, 0.7), 'PKG-B300': (0.3, 0.6, 0.8),
               'PKG-B310': (0.2, 0.4, 0.6), 'PKG-C500': (0.4, 0.8, 1.0)}


def expected_grade(product, value):
    a_limit, b_limit, c_limit = TILT_LIMITS[product]
    if value <= a_limit:
        return 'A'
    if value <= b_limit:
        return 'B'
    if value <= c_limit:
        return 'C'
    return 'OUT'


class ReportRows(HTMLParser):
    """보고서 HTML 에서 스트립 행(data-strip · data-grade · data-action)과 요약 건수를 읽습니다"""

    def __init__(self):
        super().__init__()
        self.rows = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'tr' and 'data-strip' in attrs:
            self.rows[attrs['data-strip']] = (attrs.get('data-grade'), attrs.get('data-action'))


def check_grade_tool():
    """1단계: tools/grade_tilt.py 가 명령으로 실행되고 7일차와 같은 등급을 내는지"""
    if not os.path.exists('tools/grade_tilt.py'):
        return False, 'tools/grade_tilt.py 가 없습니다'
    run = subprocess.run([sys.executable, 'tools/grade_tilt.py', 'PKG-B310', '0.45'], capture_output=True, text=True,
                         encoding='utf-8')
    try:
        grade = json.loads(run.stdout.strip().splitlines()[-1])['grade']
    except Exception:
        return False, 'python tools/grade_tilt.py PKG-B310 0.45 의 출력이 JSON 한 줄이 아닙니다'
    return grade == 'C', f'PKG-B310 0.45 → {grade} (기대 C)'


def check_skill():
    """3단계: SKILL.md(name · description), 계산 스크립트, 보고서 양식이 스킬 폴더에 있는지"""
    for path in glob.glob('.claude/skills/*/SKILL.md'):
        folder = os.path.dirname(path)
        text = open(path, encoding='utf-8-sig').read()
        has_head = re.search(r'^name:\s*\S', text, re.M) and re.search(r'^description:\s*\S', text, re.M)
        scripts = [p for p in glob.glob(folder + '/**/*.py', recursive=True) if not p.endswith('make_pdf.py')]
        has_form = glob.glob(folder + '/**/report.html', recursive=True)
        missing = [name for name, ok in [('name · description', has_head), ('계산 스크립트', scripts), ('보고서 양식', has_form)] if not ok]
        if not missing:
            return True, folder
        return False, f'{folder} 에 없는 것: ' + ', '.join(missing)
    return False, '.claude/skills/<스킬 이름>/SKILL.md 가 없습니다'


def check_reports():
    """보고서: out 폴더의 보고서마다 등급과 건수가 맞는지, 같은 등급에 같은 조치를 썼는지"""
    results = []
    actions_by_grade = {}
    for data_path in sorted(glob.glob('data/*.csv')):
        stem = os.path.basename(data_path)[:-4]
        html_path = f'out/틸트조치보고서_{stem}.html'
        if not os.path.exists(html_path):
            continue
        page = open(html_path, encoding='utf-8').read()
        parser = ReportRows()
        parser.feed(page)
        wrong = []
        counts = {'합격': 0, '재측정': 0, '보류': 0}
        for row in csv.DictReader(open(data_path, encoding='utf-8-sig')):
            grade = expected_grade(row['product'], float(row['tilt_deg']))
            counts['합격' if grade in ('A', 'B') else '재측정' if grade == 'C' else '보류'] += 1
            found = parser.rows.get(row['strip_id'])
            if not found or found[0] != grade:
                wrong.append(f"{row['strip_id']} 등급")
            elif found[1]:
                actions_by_grade.setdefault(grade, set()).add(found[1])
        text = re.sub(r'<[^>]+>', ' ', page)
        for name, count in counts.items():
            if not re.search(name + r'\s+' + str(count) + r'\s', text):
                wrong.append(f'{name} 건수')
        cited = re.search(r'\[PKG-[A-Z]+-\d+_v[\d.]+\]', text)
        detail = '등급 · 건수 맞음' if not wrong else '다름: ' + ', '.join(wrong)
        results.append((not wrong and bool(cited), f'{html_path[:-5]}.pdf · {detail} · 종합 의견 인용 {"있음" if cited else "없음"}'))
    if not results:
        return [(False, 'out 폴더에 보고서가 없습니다')]
    mixed = [grade for grade, actions in actions_by_grade.items() if len(actions) > 1]
    results.append((not mixed, '같은 등급의 조치 문구가 보고서마다 같음' if not mixed
                    else '등급별 조치 문구가 보고서마다 다름: ' + ', '.join(mixed)))
    return results


def session_table():
    """세션별 도구 실행 기록표"""
    path = 'logs/agent_log.jsonl'
    if not os.path.exists(path):
        return
    sessions = {}
    for line in open(path, encoding='utf-8'):
        record = json.loads(line)
        session = sessions.setdefault(record['session'], {'start': record['time'], 'tools': 0, 'skill': set()})
        session['tools'] += 1
        if record['tool'] == 'Skill':
            session['skill'].add(record['skill'] or '?')
    print('\n[세션별 도구 실행 기록]')
    print('  시작 시각            도구 실행  스킬')
    for session in sessions.values():
        skill = ', '.join(sorted(session['skill'])) or '-'
        print(f"  {session['start']}  {session['tools']:>6}번   {skill}")


checks = [('1단계 grade_tilt 명령', check_grade_tool()), ('3단계 스킬', check_skill())]
for result in check_reports():
    checks.append(('보고서', result))
for name, (passed, detail) in checks:
    print(f"{'통과' if passed else '실패'}  {name}: {detail}")
print(f"\n점수 {sum(passed for _, (passed, _) in checks)}/{len(checks)}")
session_table()
