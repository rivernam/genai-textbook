# 도구 실행 기록. .claude/settings.json 의 훅이 Claude Code 가 도구를 실행할 때마다 이 파일을 부릅니다.
# 세션 번호, 도구 이름, 명령 앞부분을 logs/agent_log.jsonl 에 한 줄씩 쌓습니다. 검사(check_m1.py)가 세션별 실행 횟수를 셀 때 씁니다.
import json
import os
import sys
import time

FOLDER = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
event = json.loads(sys.stdin.buffer.read().decode('utf-8', 'replace'))
tool = event.get('tool_name') or ''
if tool.startswith('mcp__ccd_'):                      # Desktop 이 안에서 쓰는 도구는 세지 않습니다
    sys.exit(0)
tool_input = event.get('tool_input') or {}
record = {
    'time': time.strftime('%Y-%m-%d %H:%M:%S'),
    'session': event.get('session_id', ''),
    'tool': tool,
    'skill': tool_input.get('skill') or tool_input.get('command', '') if tool == 'Skill' else '',
    'command': str(tool_input.get('command') or tool_input.get('file_path') or '')[:120],
}
os.makedirs(os.path.join(FOLDER, 'logs'), exist_ok=True)
with open(os.path.join(FOLDER, 'logs', 'agent_log.jsonl'), 'a', encoding='utf-8') as log:
    log.write(json.dumps(record, ensure_ascii=False) + '\n')
