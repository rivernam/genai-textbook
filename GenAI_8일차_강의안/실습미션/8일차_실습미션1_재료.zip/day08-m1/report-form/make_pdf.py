# 품질팀 보고서 양식(이 폴더의 report.html)으로 틸트 판정 조치 보고서 PDF 를 만듭니다.
# 사용: python <이 파일 경로> <보고서 json>      (day08-m1 폴더에서 실행합니다)
# 보고서 json 형식:
#   {"equipment": "DB-01", "date": "2026-01-19",
#    "rows": [{"strip_id": "STR-00290", "product": "PKG-A100", "tilt_deg": 0.77, "grade": "C", "action": "재측정(다이 5개)"}, ...],
#    "totals": {"합격": 5, "재측정": 3, "보류": 1},
#    "opinions": ["종합 의견 한 문장 [PKG-SOP-006_v1.0]", ...],
#    "basis": ["PKG-SOP-006_v1.0", ...]}
# PC 에 있는 Edge 나 Chrome 으로 인쇄해 out 폴더에 PDF 를 만듭니다.
import csv
import datetime
import html
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

FORM = Path(__file__).resolve().parent                  # 양식 폴더(스킬 폴더 안으로 옮겨도 됩니다)
WORK = Path.cwd()                                       # day08-m1 폴더
sys.stdout.reconfigure(encoding='utf-8')

BROWSERS = [
    r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
    r'C:\Program Files\Google\Chrome\Application\chrome.exe',
    r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
]
COLORS = {'합격': '#2f6f4f', '재측정': '#c58a12', '보류': '#b3261e'}


def find_browser():
    """PDF 인쇄에 쓸 브라우저 경로를 찾습니다"""
    for path in BROWSERS:
        if os.path.exists(path):
            return path
    for name in ['msedge', 'google-chrome', 'chromium', 'chrome']:
        if shutil.which(name):
            return shutil.which(name)
    return None


def doc_titles():
    """docs7_manifest.csv 에서 「문서번호_판」 → 제목"""
    titles = {}
    manifest = WORK / 'docs7_manifest.csv'
    if manifest.exists():
        for row in csv.DictReader(open(manifest, encoding='utf-8-sig')):
            titles[f"{row['doc_id']}_{row['version']}"] = row['title']
    return titles


def percent(count, total):
    return f'{100 * count / total:.0f}%' if total else '-'


def build_html(report):
    """양식의 빈칸에 보고서 내용을 채운 HTML 을 돌려줍니다"""
    totals = report['totals']
    total = len(report['rows'])
    rows = []
    for number, row in enumerate(report['rows'], start=1):
        grade = str(row['grade'])
        action = row.get('action') or row.get('disposition', '')
        rows.append(f'    <tr class="{"out" if grade == "OUT" else ""}" data-strip="{html.escape(row["strip_id"])}" '
                    f'data-grade="{grade}" data-action="{html.escape(action)}">'
                    f'<td class="c">{number}</td><td>{html.escape(row["strip_id"])}</td><td>{html.escape(row["product"])}</td>'
                    f'<td class="num">{row["tilt_deg"]}</td><td class="g g-{grade}">{grade}</td>'
                    f'<td class="act">{html.escape(action)}</td></tr>')
    bar = ''.join(f'<i style="width:{100 * totals.get(name, 0) / max(total, 1):.1f}%;background:{color}"></i>'
                  for name, color in COLORS.items())
    titles = doc_titles()
    basis = ' · '.join(f'[{html.escape(doc)}] {html.escape(titles.get(doc, ""))}'.strip() for doc in report.get('basis', []))
    opinions = '\n'.join(f'    <li>{html.escape(line)}</li>' for line in report.get('opinions', [])) or '    <li>특이 사항 없음</li>'
    fill = {
        'DOC_NO': f"QA-TILT-{report['date'].replace('-', '')}-{report['equipment']}",
        'WRITTEN': datetime.date.today().isoformat(),
        'EQUIPMENT': report['equipment'], 'DATE': report['date'], 'TOTAL': total,
        'PASS': totals.get('합격', 0), 'RECHECK': totals.get('재측정', 0), 'HOLD': totals.get('보류', 0),
        'PASS_PCT': percent(totals.get('합격', 0), total), 'RECHECK_PCT': percent(totals.get('재측정', 0), total),
        'HOLD_PCT': percent(totals.get('보류', 0), total),
        'BAR': bar, 'ROWS': '\n'.join(rows), 'OPINIONS': opinions, 'BASIS': basis or '-',
    }
    page = (FORM / 'report.html').read_text(encoding='utf-8')
    for key, value in fill.items():
        page = page.replace('{{' + key + '}}', str(value))
    return page


def main():
    if len(sys.argv) != 2:
        sys.exit('사용: python <make_pdf.py 경로> <보고서 json>')
    report = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
    name = f"틸트조치보고서_{report['equipment']}_{report['date'].replace('-', '')}"
    out_folder = WORK / 'out'
    out_folder.mkdir(exist_ok=True)
    html_path = out_folder / f'{name}.html'
    pdf_path = out_folder / f'{name}.pdf'
    html_path.write_text(build_html(report), encoding='utf-8')

    browser = find_browser()
    if not browser:
        sys.exit(f'Edge 나 Chrome 을 찾지 못했습니다. {html_path} 를 브라우저로 열어 PDF 로 인쇄해 주세요')
    if pdf_path.exists():
        pdf_path.unlink()
    with tempfile.TemporaryDirectory() as profile:        # 이미 열린 브라우저와 겹치지 않게 빈 프로필로 인쇄합니다
        subprocess.run([browser, '--headless=new', '--disable-gpu', f'--user-data-dir={profile}',
                        '--no-pdf-header-footer', '--print-to-pdf-no-header',
                        f'--print-to-pdf={pdf_path}', html_path.as_uri()],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    if not pdf_path.exists():
        sys.exit(f'PDF 를 만들지 못했습니다. {html_path} 를 브라우저로 열어 PDF 로 인쇄해 주세요')
    print(json.dumps({'pdf': str(pdf_path.relative_to(WORK)), 'rows': len(report['rows']), 'totals': report['totals']},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
