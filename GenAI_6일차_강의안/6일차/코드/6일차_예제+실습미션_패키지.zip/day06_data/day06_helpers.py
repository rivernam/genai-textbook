# -*- coding: utf-8 -*-
"""6일차 예제 · 실습 노트북이 함께 쓰는 함수 모음입니다.

노트북의 준비 셀이 이 파일을 가져옵니다. 수업에서는 함수 이름과 인자만 알면 되고,
안에서 무슨 일이 일어나는지 궁금하면 이 파일을 열어 보면 됩니다.
"""
import gc
import json
import os
import random
import time
import warnings

warnings.filterwarnings('ignore')            # 결과와 무관한 경고(진행 막대 · 형 변환 안내)를 숨깁니다
import numpy as np                           # noqa: E402
import torch                                 # noqa: E402

os.environ.setdefault('TRANSFORMERS_VERBOSITY', 'error')      # 결과와 무관한 경고를 숨깁니다
os.environ.setdefault('HF_HUB_DISABLE_PROGRESS_BARS', '1')    # 내려받기 · 올리기 진행 막대를 숨깁니다
from transformers import AutoModelForCausalLM, AutoTokenizer   # noqa: E402
from transformers.utils import logging as hf_logging            # noqa: E402

hf_logging.disable_progress_bar()

SEED = 42                                  # 난수 시드 · 같은 값이면 같은 결과가 다시 나옵니다
MODEL_NAME = 'google/gemma-4-E2B-it'       # 오늘 쓰는 sLM (파라미터 51억 개)
DTYPE = torch.bfloat16                     # 가중치를 담는 정밀도 · bf16 은 값 하나에 2바이트
DEVICE = ('cuda' if torch.cuda.is_available()
          else 'mps' if torch.backends.mps.is_available() else 'cpu')

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)   # 글자를 토큰 번호로 바꾸는 도구


def set_seed(seed=SEED):
    """파이썬 · numpy · torch 의 난수를 한꺼번에 고정합니다"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def free_memory(*variable_names):
    """노트북에서 이름으로 받은 모델을 지우고 GPU 메모리를 비웁니다.
    24GB GPU 에 모델(약 9.5GB)을 두 벌 올리면 학습할 자리가 남지 않습니다"""
    import __main__                        # 노트북의 변수 공간
    for name in variable_names:
        vars(__main__).pop(name, None)
    gc.collect()
    if DEVICE == 'cuda':
        torch.cuda.empty_cache()
    elif DEVICE == 'mps':
        torch.mps.empty_cache()


def gpu_total_gb():
    """이 GPU 의 전체 메모리(GB) · GPU 가 없는 맥에서 시험할 때는 24GB 로 셈합니다"""
    if DEVICE == 'cuda':
        return torch.cuda.get_device_properties(0).total_memory / 1024**3
    return 24.0


def facts_result(facts, key):
    """b6_facts.json 의 강사 실측값(before · after)을 evaluate() 결과와 같은 모양으로 바꿉니다"""
    return {'accuracy': facts[key]['acc'], 'format_rate': facts[key]['fmt'], 'answers': facts[key]['outs']}


def gpu_memory_gb():
    """지금 GPU 에 올라가 있는 텐서의 크기(GB)"""
    if DEVICE == 'cuda':
        return torch.cuda.memory_allocated() / 1024**3
    if DEVICE == 'mps':
        return torch.mps.current_allocated_memory() / 1024**3
    return 0.0


def load_model(quantization_config=None):
    """모델을 GPU 로 바로 올립니다. quantization_config 를 주면 int8 · int4 로 올립니다"""
    options = {'quantization_config': quantization_config} if quantization_config else {}
    return AutoModelForCausalLM.from_pretrained(MODEL_NAME, dtype=DTYPE,
                                                device_map=DEVICE, **options)


def first_word(answer_text):
    """답의 첫 단어만 꺼냅니다. 빈 답이면 빈 글자입니다"""
    words = answer_text.split()
    return words[0] if words else ''


# ───────── 과제 설정 · 프롬프트와 정답 목록 ─────────
TASK = {'prompt_template': None, 'label_names': None}


def set_task(prompt_template, label_names):
    """이 과제의 프롬프트 틀과 정답 목록을 정해 둡니다.
    build_text · evaluate · train_lora 가 이 값을 씁니다"""
    TASK['prompt_template'] = prompt_template
    TASK['label_names'] = list(label_names)


def build_text(row, with_answer=True):
    """질문 한 건을 채팅 형식으로 감쌉니다.
    with_answer=True면 뒤에 정답과 EOS 토큰을 붙여 학습 문장이 됩니다"""
    messages = [{'role': 'user', 'content': TASK['prompt_template'].format(q=row['q'])}]
    text = tokenizer.apply_chat_template(messages, tokenize=False,
                                         add_generation_prompt=True)
    return text + (row['a'] + tokenizer.eos_token if with_answer else '')


@torch.no_grad()                           # 답만 받고 학습은 하지 않는다는 표시입니다
def evaluate(model, rows):
    """문항마다 답을 생성해 첫 단어로 채점합니다.
    정확도 = 정답과 같은 비율, 형식 준수율 = 정답 목록 안의 단어로 답한 비율"""
    model.eval()
    correct = well_formed = 0
    answers = []
    start = time.perf_counter()
    for row in rows:
        # 채팅 형식 문장에 시작 표시가 이미 들어 있어 add_special_tokens=False로 둡니다
        inputs = tokenizer(build_text(row, with_answer=False), return_tensors='pt',
                           add_special_tokens=False).to(model.device)
        output_ids = model.generate(**inputs, max_new_tokens=8, do_sample=False,
                                    pad_token_id=tokenizer.pad_token_id)
        new_ids = output_ids[0][inputs['input_ids'].shape[1]:]   # 입력 뒤에 새로 생성한 부분
        answer = tokenizer.decode(new_ids, skip_special_tokens=True).strip()
        word = first_word(answer)
        answers.append(word)
        well_formed += word in TASK['label_names']
        correct += word == row['a']
    seconds = time.perf_counter() - start
    return {'accuracy': round(correct / len(rows) * 100, 1),
            'format_rate': round(well_formed / len(rows) * 100, 1),
            'seconds_per_question': round(seconds / len(rows), 2),
            'answers': answers}


def train_lora(train_rows, lora_rank=8, epochs=3, learning_rate=2e-4,
               batch_size=4, seed=SEED, show_progress=True, quantization_config=None):
    """모델을 새로 올려 LoRA 어댑터를 붙이고 train_rows로 학습한 뒤 (모델, 학습 기록)을 돌려줍니다.
    lora_rank  덧붙이는 작은 행렬의 rank(r), 클수록 학습할 값이 많습니다
    epochs     학습 데이터 전체를 몇 번 되풀이할지
    learning_rate  한 번에 가중치를 얼마나 크게 고칠지
    quantization_config  주면 원본을 그 정밀도로 줄여 올린 뒤 LoRA만 학습합니다
                         (QLoRA, quantization_for('nf4'))
    학습 기록: 에포크마다 평균 손실, 학습 시간(초), 학습한 파라미터 수"""
    from peft import LoraConfig, get_peft_model
    set_seed(seed)                         # LoRA 초기값과 학습 순서를 고정합니다
    lora_config = LoraConfig(
        r=lora_rank, lora_alpha=lora_rank * 2,   # alpha는 r의 두 배로 둡니다(r 8이면 16)
        lora_dropout=0.05, bias='none', task_type='CAUSAL_LM',
        # 이미지, 음성 층은 빼고, 글을 다루는 층의 어텐션 네 곳에만 겁니다
        target_modules=r'.*language_model.*\.(q_proj|k_proj|v_proj|o_proj)')
    # quantization_config가 없으면 bf16 원본에, 있으면 그 정밀도로 줄인 원본에 붙입니다(QLoRA)
    # 원본 가중치는 get_peft_model이 고정하고 LoRA 행렬만 학습합니다
    model = get_peft_model(load_model(quantization_config), lora_config)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    optimizer = torch.optim.AdamW(trainable, lr=learning_rate)
    order = list(train_rows)               # 원본 순서는 건드리지 않고 사본을 섞습니다
    losses = []
    model.train()
    start = time.perf_counter()
    for epoch in range(epochs):
        random.shuffle(order)              # 에포크마다 순서를 섞습니다(시드로 고정된 난수)
        loss_sum, batch_count = 0.0, 0
        for begin in range(0, len(order), batch_size):
            batch = order[begin:begin + batch_size]
            encoded = tokenizer([build_text(row) for row in batch], return_tensors='pt',
                                padding=True, truncation=True, max_length=128,
                                add_special_tokens=False).to(DEVICE)
            labels = encoded['input_ids'].clone()
            labels[encoded['attention_mask'] == 0] = -100    # 패딩 토큰은 손실에서 뺍니다
            loss = model(**encoded, labels=labels).loss       # 정답과 얼마나 다른가
            loss.backward()                                   # 줄이는 방향 계산(기울기)
            optimizer.step()                                  # 그 방향으로 LoRA 값을 고침
            optimizer.zero_grad()
            loss_sum += float(loss)
            batch_count += 1
        losses.append(round(loss_sum / batch_count, 4))
        if show_progress:
            print('에포크', epoch + 1, '· 손실', losses[-1])
    del loss, encoded, labels              # 마지막 배치의 계산 결과가 GPU에 남지 않게 지웁니다
    history = {'losses': losses,
               'seconds': round(time.perf_counter() - start, 1),
               'trainable_params': sum(parameter.numel() for parameter in trainable)}
    return model, history


@torch.no_grad()
def generate_answer(model, question, sample=False, max_new_tokens=40):
    """프롬프트 틀 없이 질문을 그대로 넣어 답을 생성합니다(망각 · 환각 점검용).
    sample=True 면 매번 다른 답이 나올 수 있게 샘플링합니다"""
    messages = [{'role': 'user', 'content': question}]
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(text, return_tensors='pt', add_special_tokens=False).to(model.device)
    output_ids = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=sample,
                                pad_token_id=tokenizer.pad_token_id)
    new_ids = output_ids[0][inputs['input_ids'].shape[1]:]
    return tokenizer.decode(new_ids, skip_special_tokens=True).strip().replace('\n', ' ')


def count_kept_answers(model, questions, key_answers):
    """일반 질문마다 핵심 답이 들어 있는지 세어 (학습 전, 학습 후) 개수를 돌려줍니다.
    disable_adapter() 안에서는 어댑터를 뗀 학습 전 모델이 답합니다"""
    with model.disable_adapter():
        before = sum(key in generate_answer(model, question)
                     for question, key in zip(questions, key_answers))
    after = sum(key in generate_answer(model, question)
                for question, key in zip(questions, key_answers))
    return before, after


def compare_answers(before_answers, after_answers, rows):
    """학습 전후 답을 문항마다 견줘 (좋아진 문항, 나빠진 문항) 목록을 돌려줍니다"""
    pairs = list(zip(before_answers, after_answers, rows))
    improved = [row for before, after, row in pairs if before != row['a'] and after == row['a']]
    worsened = [row for before, after, row in pairs if before == row['a'] and after != row['a']]
    return improved, worsened


def sample_by_label(rows, ratio, seed=SEED):
    """정답 종류마다 같은 비율로 뽑습니다. 앞에서 n건을 자르면 종류가 한쪽으로 쏠립니다"""
    picker = random.Random(seed)
    picked = []
    for label in sorted({row['a'] for row in rows}):
        group = [row for row in rows if row['a'] == label]
        picked += picker.sample(group, max(1, round(len(group) * ratio)))
    return picked


def fit_precision(params_billion, limit_gb):
    """파라미터 수(B)로 bf16 → int8 → int4 순서로 한도 안에 처음 들어가는 정밀도를 고릅니다"""
    for precision, bytes_per_value in [('bf16', 2), ('int8', 1), ('int4', 0.5)]:
        if params_billion * 1e9 * bytes_per_value / 1024**3 <= limit_gb:
            return precision
    return '없음'


def quantization_for(precision):
    """'int8' · 'int4' · 'nf4' 에 맞는 bitsandbytes 설정을 만듭니다. 'bf16' 이면 None
    nf4 는 QLoRA 논문의 4비트 형식(NormalFloat4)이고, 학습할 때(QLoRA) 씁니다"""
    from transformers import BitsAndBytesConfig
    if precision == 'int8':
        return BitsAndBytesConfig(load_in_8bit=True)
    if precision == 'nf4':
        return BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4',
                                  bnb_4bit_compute_dtype=torch.bfloat16)
    if precision == 'int4':
        return BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16)
    return None


def measure_precision(precision, adapter_dir, evalset):
    """어댑터를 붙인 모델을 정밀도 하나로 올려 메모리 · 정확도 · 건당 시간을 재고 내립니다"""
    import logging
    from peft import PeftModel
    logging.getLogger('bitsandbytes').setLevel(logging.ERROR)   # int8 형 변환 안내를 숨깁니다
    free_memory()
    model = PeftModel.from_pretrained(load_model(quantization_for(precision)), adapter_dir)
    memory = gpu_memory_gb()
    result = evaluate(model, evalset)
    del model
    free_memory()
    return dict(result, memory_gb=round(memory, 1))


def load_json(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)



def make_title_rows(documents, label_names, eval_ratio=0.2, seed=SEED):
    """문서 제목을 질문(q), 문서 유형을 정답(a)으로 하는 행을 만들고 학습 데이터와 평가셋으로 나눕니다.
    같은 제목은 한 건만 남깁니다(같은 제목이 양쪽에 들어가면 점수가 부풀려집니다).
    유형마다 eval_ratio 만큼을 평가셋으로 떼고, 전용 난수를 써서 언제 실행해도 같은 분할이 나옵니다"""
    all_rows, seen_titles = [], set()
    for document in documents.values():
        if document['title'] not in seen_titles:
            seen_titles.add(document['title'])
            all_rows.append({'q': document['title'], 'a': document['type']})
    splitter = random.Random(seed)
    train_rows, evalset = [], []
    for label in label_names:
        group = [row for row in all_rows if row['a'] == label]
        splitter.shuffle(group)
        eval_count = max(1, round(len(group) * eval_ratio))
        evalset += group[:eval_count]
        train_rows += group[eval_count:]
    splitter.shuffle(train_rows)
    splitter.shuffle(evalset)
    return all_rows, train_rows, evalset


class ClaudeCaller:
    """Claude API 를 호출하는 도구입니다. 키가 없으면 cache_path 에 저장해 둔 강사 실측 답을 꺼냅니다.
    키는 입력 칸으로 받고 화면과 노트북 파일에 남기지 않습니다"""

    def __init__(self, cache_path, model_name='claude-opus-5-5'):
        import getpass
        self.cache_path, self.model_name = cache_path, model_name
        self.cache = load_json(cache_path) if os.path.exists(cache_path) else {}
        if not os.environ.get('ANTHROPIC_API_KEY'):
            try:
                key = getpass.getpass('Claude API 키 (없으면 Enter): ').strip()
            except Exception:          # 입력 칸을 띄울 수 없는 실행 방식이면 키 없이 갑니다
                key = ''
            if key:
                os.environ['ANTHROPIC_API_KEY'] = key
        self.live = bool(os.environ.get('ANTHROPIC_API_KEY'))
        self.input_tokens = self.output_tokens = 0     # 실제로 쓴 토큰을 셉니다
        if self.live:
            import anthropic
            self.client = anthropic.Anthropic()

    def ask(self, prompt):
        import hashlib
        cache_key = hashlib.sha256(json.dumps([self.model_name, prompt], ensure_ascii=False)
                                   .encode()).hexdigest()[:16]
        if not self.live:
            return self.cache.get(cache_key, {}).get('text', '[캐시에 없는 질문]')
        response = self.client.beta.messages.create(
            model=self.model_name, max_tokens=256,
            output_config={'effort': 'low'},          # 짧은 분류라 생각을 줄입니다
            betas=['server-side-fallback-2026-07-01'],
            fallbacks='default',                      # 거절되면 다른 모델로 다시 답합니다
            messages=[{'role': 'user', 'content': prompt}])
        self.input_tokens += response.usage.input_tokens
        self.output_tokens += response.usage.output_tokens
        text = ''.join(block.text for block in response.content if block.type == 'text').strip()
        self.cache[cache_key] = {'text': text}
        with open(self.cache_path, 'w', encoding='utf-8') as f:   # 받은 답을 캐시 파일에도 남깁니다
            json.dump(self.cache, f, ensure_ascii=False, indent=1)
        return text
